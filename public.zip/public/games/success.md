# App Opened!
---
Success! The app has been opened.
Didn't work? Try enabling javascript in your [browser settings](chrome://settings)!
